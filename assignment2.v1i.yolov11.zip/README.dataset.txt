# assignment2_v1 > 2025-12-25 12:19pm
https://universe.roboflow.com/public-amgsc/assignment2_v1

Provided by a Roboflow user
License: CC BY 4.0

