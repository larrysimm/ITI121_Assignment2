# assignment2 > 2025-12-07 1:43pm
https://universe.roboflow.com/public-amgsc/assignment2-ns97p

Provided by a Roboflow user
License: CC BY 4.0

